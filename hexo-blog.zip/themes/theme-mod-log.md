theme-mod-log
================

使用主题为hexo-theme-indigo [作者博客](http://www.imys.net/)

在此基础上做了稍许修改。

## 修改记录 

1. 修改 indigo\layout\_partial\footer.ejs，去掉了下方部分分享图标
2. 修改 indigo\source\css\_partial\header.less 修改顶部高度，使其与左侧高度对齐
3. 修改 indigo\source\css\_partial\variable.less 修改顶部颜色，使其与最顶部的工具组有区别
4. 修改 indigo\source\img\ 下的两张打赏图片
5. 修改 indigo\source\css\partial\variable.less 字体大小
6. 修改 indigo\source\css\style.less 添加img-box类

7. 修改 .menu下的.footer样式
8. 添加音乐播放块