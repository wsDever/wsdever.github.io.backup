本项目介绍
================

博客站点备份，无其它用处。
预览 [我的博客](http://wsdever.github.io/),
若打不开时请尝试打开 [备用博客](http://wslover.66ghz.com/)
学习尚可，切勿做其它之用！
# 学习基础
基于 nodejs + hexo + less 等搭建。

## 使用
首先把项目 clone 下面来，然后
```
npm install 
```
安装需要的依赖，然后执行
```
hexo init 
```
```
hexo generate(g) 
```
```
hexo server(s)
```
有修改时，需要将更改发布到网站
```
hexo clean 
```
```
hexo generate(g) 
```
```
hexo deploy(d)