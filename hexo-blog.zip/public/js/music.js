/*
 * @author		DenGo
 * @email		i@dengo.org
 * @link		http://dengo.org
 * @date		2014-05-24
 * @project		HTML5_Player
 * @description	基于html5和css3编写的音乐播发器
 */

window.onload=function(){
	function $(ele){
		return document.querySelector(ele);
	}

	var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    var aver = new Image();
    var timer = 0 ;
	//=========================================保存初始化数据
	var audio = $('#audio');
	var musicMode = 'list';
	var musicIndex = 1;
	var bufferTimer = null;
	var volumeTimer = null;

	//============================================绑定事件
	$('.play').onclick=function(){
		toPlay('play');
	}

	$('.pause').onclick=function(){
		toPlay('pause');
	}

	$('.prev').onclick=function(){
		toPlay('prev');
	};

	$('.next').onclick=function(){
		toPlay('next');
	};

	//调整播放时间
	$('.progress_bar').onclick=function(ev){
		adjustPorgress(this,ev);
	};

	//音量调节--延时隐藏调节面板
	$('.volume').onmouseover=$('.volume_wrap').onmouseover=function(){
		clearTimeout(volumeTimer);
		removeClass($('.volume_wrap'),'hidden')
	};

	$('.volume').onmouseout=$('.volume_wrap').onmouseout=function(){
		volumeTimer = setTimeout(function(){
			addClass($('.volume_wrap'),'hidden');
		},300);
	};

	$('.volume_bar').onclick=function(ev){
		adjustVolume(this,ev);
	};

	//是否静音
	$('.volume').onclick=function(){
		if (audio.muted == false) {
			this.style.color = '#A1A1A1';
			audio.muted = true;
		}
		else if (audio.muted == true) {
			this.style.color = '#E74D3C';
			audio.muted = false;
		};
	};

	//播放模式
	$('.repeat').onclick=function(){
		changeMusicMode(this,'repeat');
	};

	$('.shuffle').onclick=function(){
		changeMusicMode(this,'shuffle');
	};

	$('.list').onclick=function(){
		changeMusicMode(this,'list');
	};

	//===============================================初始化播放器
	initPlayer(musicIndex-1);
	audio.volume = 0.8;
	audio.addEventListener('canplay',bufferBar,false);

	function initPlayer(index){
		//音乐路径
		audio.setAttribute('src',playList[index].musicURL);
		//歌手
		$('.artist_name').innerHTML = playList[index].artist;
		//头像
		aver.src = playList[index].avatarURL ;
		// $('.artist_avatar img').setAttribute('src',playList[index].avatarURL);
		//歌名
		$('.music_name').innerHTML = playList[index].musicName;
		//专辑
		$('.music_album').innerHTML = playList[index].musicAlbum;
		//进度条
		$('.progress').style.width =   0 +'px';
		//缓冲进度条
		audio.removeEventListener('canplay',bufferBar,false);
		clearInterval(bufferTimer);
		$('.buffer').style.width = 0 +'px';
		// timer = setInterval(DrawPic ,50);
		// drawdvd();
		aver.addEventListener('load', drawdvd, false);
	}
	function DrawPic(){
        upangle();
        drawdvd();
      }
      var dvdangle = 0 ;
      function upangle()
      {
         dvdangle += 1 ;
      }
      function drawdvd(){

        var pam = ctx.createPattern(aver,'no-repeat');
        ctx.fillStyle = pam ;
        ctx.beginPath();

        ctx.lineWidth = "1";
        ctx.strokeStyle = "#B1D3CC";
        ctx.save();   

        ctx.arc(45, 45, 40, 0,2*Math.PI); 
        ctx.translate(45,45); 

        ctx.rotate(dvdangle/180*Math.PI);  
        ctx.translate(-45,-45);      
        ctx.fill();
        ctx.stroke()
        ctx.restore();
        

        ctx.beginPath();
        ctx.fillStyle = "rgba(255,255,255,1)" ;
        ctx.arc(45, 45, 16, 0,2*Math.PI);      
        
        ctx.fill();
        ctx.stroke();
      }

	//=================================================播放
	function toPlay(action){
		if (action == 'play') {
			audio.play();
			removeClass($('.pause'),'hidden');
			addClass($('.play'),'hidden');
			timer = setInterval(DrawPic ,50);
		}
		else if (action == 'pause') {
			audio.pause();
			removeClass($('.play'),'hidden');
			addClass($('.pause'),'hidden');
			clearInterval(timer);
		}
		else if (action == 'prev') {
			playMusicMode(action);
			
		}
		else if (action == 'next') {
			playMusicMode(action);
			
		};
	}

	//==============================================播放结束后播放下一曲
	audio.addEventListener('ended',function(){
		playMusicMode('ended');
	},false);

	//==============================================根据播放模式计算歌曲索引
	function playMusicMode(action){
		clearInterval(timer);

		var musicNum = playList.length;
		var index = musicIndex;

		//列表循环
		if (musicMode == 'list' ) {
			if (action == 'prev') {
				if (index == 1) { //如果是第一首歌，跳到最后一首
					index = musicNum;
				}
				else{
					index -= 1;
				}
			}
			else if (action == 'next' || action == 'ended') {
				if (index == musicNum) {//如果是最后一首歌，跳到第一首
					index = 1;
				}
				else{
					index += 1;
				}
			};
		};

		//随机播放
		if (musicMode == 'shuffle') {
			var randomIndex = parseInt(musicNum * Math.random());
			index = randomIndex + 1;
			if (index == musicIndex) {//下一首和当前相同，跳到下一首
				index += 1;
			};
		};

		//单曲循环
		if (musicMode == 'repeat') {
			if (action == 'prev') {
				if (index == 1) { //如果是第一首歌，跳到最后一首
					index = musicNum;
				}
				else{
					index -= 1;
				}
			}
			else if (action == 'next') {
				if (index == musicNum) {//如果是最后一首歌，跳到第一首
					index = 1;
				}
				else{
					index += 1;
				}
			}else{
				//if ended 如果是播放结束自动跳转，不做操作
			}
		};

		musicIndex = index;
		playIndex(index-1);
	}

	//================================================更新歌曲播放索引，重新加载歌曲，并播放
	function playIndex(index){
		initPlayer(index);
		audio.load();
		audio.addEventListener('canplay',bufferBar,false);
		toPlay('play');
	}

	//===============================================更改播放模式
	function changeMusicMode(dom,mode){
		musicMode = mode;
		var option = $('#option_list').getElementsByTagName('li');
		for (var i = 0; i < option.length; i++) {
			option[i].style.color = '#A1A1A1';
		};
		dom.style.color = '#E74D3C';
	}

	//=============================================显示剩余时间 和 播放进度条
	audio.addEventListener('timeupdate',function(){
		if (!isNaN(audio.duration)) {
			//剩余时间
			var surplus = audio.duration-audio.currentTime;
			// 对歌词进行处理
			// addMusicLrc(audio.currentTime);			
			var surplusMin = parseInt(surplus/60);
			var surplusSecond = parseInt(surplus%60);
			if (surplusSecond < 10 ) {
				surplusSecond = '0'+surplusSecond;
			};
			$('.time').innerHTML = "-" + surplusMin + ":" +surplusSecond;

			//播放进度条
			var progressValue = audio.currentTime/audio.duration*200;
			$('.progress').style.width = parseInt(progressValue) + 'px';
		};
	},false);

	//===============================================显示缓冲进度条
	function bufferBar(){
		bufferTimer = setInterval(function(){
			var bufferIndex = audio.buffered.length;
			if (bufferIndex > 0 && audio.buffered != undefined) {
				var bufferValue = audio.buffered.end(bufferIndex-1)/audio.duration*200;
				$('.buffer').style.width = parseInt(bufferValue)+'px';

				if (Math.abs(audio.duration - audio.buffered.end(bufferIndex-1)) <1) {
					$('.buffer').style.width = 200+'px';
					clearInterval(bufferTimer);
				};
			};
		},1000);
	}

	//=============================================调整播放进度条
	function adjustPorgress(dom,ev){
		var event = window.event || ev;
		var progressX = event.clientX - dom.getBoundingClientRect().left;
		audio.currentTime = parseInt(progressX/200*audio.duration);
		audio.removeEventListener('canplay',bufferBar,false);
	}

	//===============================================调整音量条
	function adjustVolume(dom,ev){
		var event = window.event || ev;
		var volumeY = dom.getBoundingClientRect().bottom - event.clientY;
		audio.volume = (volumeY/80).toFixed(2);
		$('.volume_now').style.height = volumeY + 'px';
 	};


	//=============================================对class操作的工具函数
	function hasClass(dom,className){
		var classNum = dom.className.split(" "),
			hasClass;

		for (var i = 0; i < classNum.length; i++) {
			if (classNum[i] == className) {
				hasClass = true;
				break;
			}
			else{
				hasClass = false;
			};
		};

		return hasClass;
	}

	function addClass(dom,className){
		if (!hasClass(dom,className)) {
			dom.className += " " + className;
		};
	}

	function removeClass(dom,className){
		if (hasClass(dom,className)) {
			var classNum = dom.className.split(" ");
			for (var i = 0; i < classNum.length; i++) {
				if (classNum[i] == className) {
					classNum.splice(i,1);
					dom.className = classNum.join(" ");
					break;
				};
			};
		};
	}

	function replaceClass(dom,className,replaceClass){
		if (hasClass(dom,className)) {
			var classNum = dom.className.split(" ");
			for (var i = 0; i < classNum.length; i++) {
				if (classNum[i] == className) {
					classNum.splice(i,1,replaceClass);
					dom.className = className.join(" ");
					break;
				};
			};
		};
	}

}
